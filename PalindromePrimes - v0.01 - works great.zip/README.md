# Math - Prime Numbers - Palindrome Primes

I invented these - or thought I had - in the hope of adding a sequence to OEIS (https://oeis.org/).

But, a quick search of the OEIS dashed my hopes, the sequence is already in the OEIS:
* https://oeis.org/A002385

Oh well, will keep searching for something to add to the OEIS ...

Mike O
